<?php

$v1 = "politeknik";
$v2 = "Pinang";
$v3 = "Seberang";
$v4 = "Teknologi Maklumat";
$v5 = "politeknik";


echo "Politeknik Balik Pualau (PBU) merupakan $v1 yang ke 21 di Malaysia dan<br>";
echo "politeknik yang kedua di Pulau $v2. PBU telah ditubuhkan pada 1 Februari 2007<br>";
echo "dan telah beroperai dalam tiga fasa. Pengoperasian PBU dalam fasa pertama adalah di<br>";
echo "Politeknik $v3 Perai, Pulau Pinang dengan menawarkan Kursus Sijil $v4<br>";
echo "dan kemasukan pelajar yang pertama adalah pada bulan Julai $v5";

?>