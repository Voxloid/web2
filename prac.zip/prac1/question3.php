<?php

echo "MATEMATIK<br>";
echo "-------------------<br>";

Hasil_Bahagi();


function Hasil_Bahagi(){
	$num1 = 12;
	$num2 = 4;
	$hasil = $num1 / $num2;

	echo "Hasil Bahagi $num1 dan 4 ialah $hasil";

}


?>