<?php

$Banana = array('susu', 'berangan', 'emas', 'nangka', 'raja');


echo "Buah pisang $Banana[0] mempunyai rasa lemak manis dan beraroma. Ia boleh dimakan begitu sahaja sebagai pencuci mulut.<br> Pokoknya yang agak rendah membolehkan buahnya dicapai dengan tangan.<br><br>";

echo "Buah pisang $Banana[1] sering menjadi pilihan ramai kerana mempunyai saiz yang sangat sesuai untuk dijadikan makanan<br> pencuci mulut yang biasanya dihidangkan di majlis- majlis keramaian dan jamuan. Pisang $Banana[2] memiliki bentuk yang<br> kecil dan sering dijadikan snek kerana rasanya yang sangat sedap<br><br>";

echo "Salah satu jenis pisang yang biasa ditanam ialah pokok pisang $Banana[3]. Buah pisang ini agak berbeza dengan pisang lain<br> kerana walaupun sudah matang, warnanya masih hijau. Pisang $Banana[4] dikatakan memiliki rasa yang paling enak dan<br> sangat sesuai dijadikan pisang goreng berbanding buah pisang lain";

?>