<?php
if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $message = $_POST['message'];
    header("Location: cookie2.php?name=$name&message=$message");
    exit();
}
?>

<form method="post" action="cookie1.php">
    <table>
        <tr>
            <td>Nama:</td>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>Mesej:</td>
            <td><input type="text" name="message"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Send"></td>
        </tr>
    </table>
</form>
