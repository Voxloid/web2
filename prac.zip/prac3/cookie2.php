<?php
if (isset($_GET['name']) && isset($_GET['message'])) {
    $name = $_GET['name'];
    $message = $_GET['message'];

    echo "Selamat Datang, $name<br>";
    echo "Mesej anda: $message<br>";

    setcookie("name", $name, time() + 60);
    setcookie("message", $message, time() + 60);
}
?>
