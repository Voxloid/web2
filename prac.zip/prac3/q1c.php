<?php
echo "MATEMATIK<br>";
echo "\" \"<br>";

Hasil_Darab();

function Hasil_Darab() {
    $num1 = 3;
    $num2 = 7;
    $hasil = $num1 * $num2;
    echo "Multiplication of $num1 and $num2 is $hasil";
}
?>
