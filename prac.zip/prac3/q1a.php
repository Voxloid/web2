<?php
$nama = "Zulqarnain Bin Ahmad";
$matrik = "DDT012F001";
$subjek = "DFP50193 - Web Programming";
$semester = "Empat (4)";
$institusi = "Politeknik Balik Pulau";

echo "Nama saya ialah $nama merupakan seorang pelajar $institusi.<br>";
echo "Nombor matrik saya bernombor $matrik.<br>";
echo "Saya belajar subjek $subjek pada sesi 2021/2022.<br>";
echo "Saya sekarang berada di semester $semester.";
?>
