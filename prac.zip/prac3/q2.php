<?php
// Initialize variables
$name = $email = $manufacturer = $place = "";
$nameErr = $emailErr = $manufacturerErr = $placeErr = "";
$showMessage = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $manufacturer = $_POST["manufacturer"];
    $place = $_POST["place"];

    // Validate
    if (empty($name)) $nameErr = "* Name is required";
    if (empty($email)) $emailErr = "* Email is required";
    if (empty($manufacturer)) $manufacturerErr = "* Manufacturer is required";
    if (empty($place)) $placeErr = "* Place is required";

    // Show message if no errors
    if (empty($nameErr) && empty($emailErr) && empty($manufacturerErr) && empty($placeErr)) {
        $showMessage = true;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sanrizo Automotive</title>
    <style>
        .error { color: red; }
    </style>
</head>
<body>

<h1><strong>SANRIZO AUTOMOTIVE BUSINESS GROUP</strong></h1>
<p>Sell Your Car to Sanrizo</p>
<p><strong>Get Your Car's Price Within Minutes – It's Fast And Easy!</strong>

<form method="post" action="">
    Name: <input type="text" name="name" value="<?php echo $name; ?>">
    <span class="error"><?php echo $nameErr; ?></span><br><br>

    Email: <input type="text" name="email" value="<?php echo $email; ?>">
    <span class="error"><?php echo $emailErr; ?></span><br><br>

    Manufacturer:
    <select name="manufacturer">
        <option value="">Select...</option>
        <option value="Proton" <?php if($manufacturer=="Proton") echo "selected"; ?>>Proton</option>
        <option value="Perodua" <?php if($manufacturer=="Perodua") echo "selected"; ?>>Perodua</option>
    </select>
    <span class="error"><?php echo $manufacturerErr; ?></span><br><br>

    Place of Inspection:
    <select name="place">
        <option value="">Select...</option>
        <option value="Penang" <?php if($place=="Penang") echo "selected"; ?>>Penang</option>
        <option value="Kedah" <?php if($place=="Kedah") echo "selected"; ?>>Kedah</option>
    </select>
    <span class="error"><?php echo $placeErr; ?></span><br><br>

    <input type="submit" value="Submit Order">
    <br><br>
</form>

<?php
if ($showMessage) {
    echo "Hi $name, you choose $manufacturer manufacturer.<br>";
    echo "Workshop is in $place. An appointment detail has been sent to $email.";
    echo "</div>";
}
?>

</body>
</html>
